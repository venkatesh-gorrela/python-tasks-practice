create Table studentmarks
(
 marks int
);

insert into studentmarks(marks) VALUES(30);