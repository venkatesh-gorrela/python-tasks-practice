import mysql.connector

# Establishing a connection to the MySQL server
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="Venky@19999"
)
print(mydb)

# Creating a cursor object to interact with the MySQL server
mycursor = mydb.cursor()
mycursor.execute("SHOW DATABASES")
for x in mycursor:
  print(x)




# Selecting the database you want to use
mycursor.execute("USE venky")

# Executing a query to retrieve data from a table in the selected database
mycursor.execute("SELECT * FROM food_items")

# Fetching the results of the query
result = mycursor.fetchall()

# Displaying the results
for row in result:
    print(row)


# # Creating a table for groceries
# mycursor.execute("CREATE TABLE groceries (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), price FLOAT, category VARCHAR(255), quantity INT)")

# # Inserting data into the table
# sql = "INSERT INTO groceries (name, price, category, quantity) VALUES (%s, %s, %s, %s)"
# val = ("Bananas", 0.49, "Fruits", 10)
# mycursor.execute(sql, val)

# # Displaying the grocery items in the table
# mycursor.execute("SELECT * FROM ")
# myresult = mycursor.fetchall()
# for x in myresult:
#   print(x)

