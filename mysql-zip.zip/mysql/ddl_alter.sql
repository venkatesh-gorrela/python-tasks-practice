
ALTER TABLE Mobile_Records ADD Mobile_Color Varchar(50);



ALTER TABLE Mobile_Records Drop Column Mobile_Color;