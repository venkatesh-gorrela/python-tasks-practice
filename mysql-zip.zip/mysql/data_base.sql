Create Database Kirandb;
show Databases;
use databasename;
SELECT DATABASE();
Drop databaseName;