from django.contrib import admin
from gvlapp.models import Demomodel

# Register your models here.

admin.site.register(Demomodel)


