from django.apps import AppConfig


class GvlappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gvlapp'
